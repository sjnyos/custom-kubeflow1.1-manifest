.
==================================================

# NAME

  .

# SYNOPSIS

  kubectl apply --recursive -f .

# Description

sample description

# SEE ALSO

